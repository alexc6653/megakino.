
import { Movie } from './types';

export const INITIAL_MOVIES: Movie[] = [];

export const CATEGORIES: string[] = ['All', 'Action', 'Drama', 'Sci-Fi', 'Comedy', 'Horror', 'Thriller'];
